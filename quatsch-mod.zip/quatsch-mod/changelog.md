# v1.0.0
- Erste Version: Furz-Modus, Rückwärts-Modus, Schüttel-Menü, Aufgeben-Popup, Mensch-Check
