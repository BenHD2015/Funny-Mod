# Quatsch Mod

Eine bewusst bescheuerte Mod. Jedes Feature kannst du in den Mod-Einstellungen einzeln ausschalten.

- **Furz-Modus:** Bei jedem Sprung ertönt ein Furzgeräusch
- **Rückwärts-Modus:** Das Level ist gespiegelt
- **Schüttel-Menü:** Die Hauptmenü-Buttons hüpfen und drehen sich
- **Aufgeben-Popup:** Im Level fragt dich regelmäßig ein Popup, ob du aufgeben willst (riesiges Nein, winziges Ja)
- **Mensch-Check:** Du musst regelmäßig eine Rechenaufgabe lösen, um zu beweisen, dass du ein Mensch bist
