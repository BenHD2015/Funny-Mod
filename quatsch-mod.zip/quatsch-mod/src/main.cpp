#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <algorithm>
#include <random>
#include <vector>

using namespace geode::prelude;

// ---------------------------------------------------------------
// Hilfsfunktionen
// ---------------------------------------------------------------
static bool on(char const* id) {
    return Mod::get()->getSettingValue<bool>(id);
}

static float seconds(char const* id) {
    return static_cast<float>(Mod::get()->getSettingValue<int64_t>(id));
}

static std::mt19937& rng() {
    static std::mt19937 r{std::random_device{}()};
    return r;
}

static int randInt(int lo, int hi) {
    return std::uniform_int_distribution<int>(lo, hi)(rng());
}

static bool s_giveUpOpen = false;
static bool s_humanOpen = false;
static float s_giveUpTimer = 0.f;
static float s_humanTimer = 0.f;

// ---------------------------------------------------------------
// Popup: "Willst du aufgeben?" (riesiges Nein, winziges Ja)
// ---------------------------------------------------------------
class GiveUpPopup : public Popup<> {
protected:
    bool setup() override {
        this->setTitle("Aufgeben?");

        auto label = CCLabelBMFont::create("Willst du wirklich aufgeben?", "bigFont.fnt");
        label->setScale(0.5f);
        m_mainLayer->addChildAtPosition(label, Anchor::Center, {0.f, 28.f});

        auto noSpr = ButtonSprite::create("Nein, weiter!");
        auto noBtn = CCMenuItemSpriteExtra::create(
            noSpr, this, menu_selector(GiveUpPopup::onNo)
        );
        noBtn->setScale(1.25f);
        m_buttonMenu->addChildAtPosition(noBtn, Anchor::Center, {0.f, -14.f});

        auto yesSpr = ButtonSprite::create("Ja");
        auto yesBtn = CCMenuItemSpriteExtra::create(
            yesSpr, this, menu_selector(GiveUpPopup::onYes)
        );
        yesBtn->setScale(0.3f);
        m_buttonMenu->addChildAtPosition(yesBtn, Anchor::Center, {118.f, -62.f});

        return true;
    }

    void onNo(CCObject*) {
        this->onClose(nullptr);
    }

    void onYes(CCObject*) {
        this->onClose(nullptr);
        if (auto pl = PlayLayer::get()) {
            pl->onQuit();
        }
    }

public:
    ~GiveUpPopup() override {
        s_giveUpOpen = false;
    }

    static GiveUpPopup* create() {
        auto ret = new GiveUpPopup();
        if (ret->initAnchored(300.f, 170.f)) {
            ret->autorelease();
            s_giveUpOpen = true;
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

// ---------------------------------------------------------------
// Popup: Mensch-Check (Rechenaufgabe, nicht wegklickbar)
// ---------------------------------------------------------------
class HumanCheckPopup : public Popup<> {
protected:
    CCLabelBMFont* m_question = nullptr;
    CCLabelBMFont* m_status = nullptr;
    std::vector<CCNode*> m_answerButtons;
    int m_correct = 0;

    bool setup() override {
        this->setTitle("Bist du ein Mensch?");
        if (m_closeBtn) m_closeBtn->setVisible(false);

        m_question = CCLabelBMFont::create("", "bigFont.fnt");
        m_question->setScale(0.7f);
        m_mainLayer->addChildAtPosition(m_question, Anchor::Center, {0.f, 28.f});

        m_status = CCLabelBMFont::create("Beweise es mit der richtigen Antwort.", "chatFont.fnt");
        m_status->setScale(0.7f);
        m_mainLayer->addChildAtPosition(m_status, Anchor::Center, {0.f, -58.f});

        this->newQuestion();
        return true;
    }

    void newQuestion() {
        for (auto btn : m_answerButtons) {
            btn->removeFromParent();
        }
        m_answerButtons.clear();

        int a = randInt(2, 9);
        int b = randInt(2, 9);
        m_correct = a + b;
        m_question->setString(fmt::format("Was ist {} + {}?", a, b).c_str());

        std::vector<int> options = {
            m_correct,
            m_correct + randInt(1, 3),
            m_correct - randInt(1, 3)
        };
        std::shuffle(options.begin(), options.end(), rng());

        for (size_t i = 0; i < options.size(); i++) {
            auto spr = ButtonSprite::create(std::to_string(options[i]).c_str());
            auto btn = CCMenuItemSpriteExtra::create(
                spr, this, menu_selector(HumanCheckPopup::onAnswer)
            );
            btn->setTag(options[i]);
            m_buttonMenu->addChildAtPosition(
                btn, Anchor::Center, {(static_cast<float>(i) - 1.f) * 78.f, -14.f}
            );
            m_answerButtons.push_back(btn);
        }
    }

    void onAnswer(CCObject* sender) {
        int value = static_cast<CCNode*>(sender)->getTag();
        if (value == m_correct) {
            this->onClose(nullptr);
        } else {
            m_status->setString("Roboter erkannt! Nochmal.");
            m_status->setColor({255, 80, 80});
            this->newQuestion();
        }
    }

    // Zurueck-Taste (Android) und ESC schliessen das Popup NICHT
    void keyBackClicked() override {}

public:
    ~HumanCheckPopup() override {
        s_humanOpen = false;
    }

    static HumanCheckPopup* create() {
        auto ret = new HumanCheckPopup();
        if (ret->initAnchored(300.f, 170.f)) {
            ret->autorelease();
            s_humanOpen = true;
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

// ---------------------------------------------------------------
// Furz-Modus: Sound bei jedem Sprung
// ---------------------------------------------------------------
class $modify(FartPlayerObject, PlayerObject) {
    bool pushButton(PlayerButton btn) {
        bool ret = PlayerObject::pushButton(btn);
        if (btn == PlayerButton::Jump && on("fart-mode")) {
            auto pl = PlayLayer::get();
            if (pl && this == pl->m_player1) {
                FMODAudioEngine::sharedEngine()->playEffect("fart.wav"_spr);
            }
        }
        return ret;
    }
};

// ---------------------------------------------------------------
// Rueckwaerts-Modus: ganzes Level spiegeln
// ---------------------------------------------------------------
class $modify(MirrorPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

        if (on("mirror-mode")) {
            auto win = CCDirector::get()->getWinSize();
            this->setScaleX(-1.f);
            this->setPositionX(win.width);
        }
        return true;
    }
};

// ---------------------------------------------------------------
// Schuettel-Menue: Hauptmenue-Buttons huepfen und drehen sich
// ---------------------------------------------------------------
static void shakeNode(CCNode* node) {
    float delay = static_cast<float>(randInt(0, 100)) / 100.f * 0.2f;

    auto rot = CCSequence::create(
        CCRotateTo::create(0.09f, 7.f),
        CCRotateTo::create(0.09f, -7.f),
        nullptr
    );
    auto hop = CCSequence::create(
        CCMoveBy::create(0.09f, {0.f, 5.f}),
        CCMoveBy::create(0.09f, {0.f, -5.f}),
        nullptr
    );
    node->runAction(CCSequence::create(
        CCDelayTime::create(delay),
        CCRepeatForever::create(CCSpawn::create(rot, hop, nullptr)),
        nullptr
    ));
}

class $modify(ShakeMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        if (!on("shake-menu")) return true;

        for (auto id : {
            "main-menu", "bottom-menu", "right-side-menu",
            "side-menu", "profile-menu", "close-menu", "top-right-menu"
        }) {
            auto menu = this->getChildByID(id);
            if (!menu || menu->getChildrenCount() == 0) continue;
            for (auto child : CCArrayExt<CCNode*>(menu->getChildren())) {
                shakeNode(child);
            }
        }
        return true;
    }
};

// ---------------------------------------------------------------
// Timer fuer beide Popups (laeuft ueberall, auch im Level)
// ---------------------------------------------------------------
class $modify(ChaosScheduler, CCScheduler) {
    void update(float dt) {
        CCScheduler::update(dt);

        if (!CCDirector::get()->getRunningScene()) return;

        if (on("human-check") && !s_humanOpen) {
            s_humanTimer += dt;
            if (s_humanTimer >= seconds("human-check-interval")) {
                s_humanTimer = 0.f;
                s_giveUpTimer = 0.f;
                if (auto popup = HumanCheckPopup::create()) {
                    popup->show();
                }
                return;
            }
        }

        if (on("give-up-popup") && !s_giveUpOpen && !s_humanOpen && PlayLayer::get()) {
            s_giveUpTimer += dt;
            if (s_giveUpTimer >= seconds("give-up-interval")) {
                s_giveUpTimer = 0.f;
                if (auto popup = GiveUpPopup::create()) {
                    popup->show();
                }
            }
        }
    }
};
